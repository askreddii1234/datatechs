import React, { useState, useCallback } from 'react';
import { Bot, Code, FileText, Send, Download, Briefcase, LogIn, UserPlus, Github, Twitter, Linkedin, Sparkles, Check, Crown, Zap } from 'lucide-react';

interface ResumeData {
  name: string;
  skills: string;
  experience: string;
  certifications: string;
}

interface AIAnalysis {
  keywords: string;
  summary: string;
  projects: string;
  responsibilities: string;
  coverLetter: string;
  linkedinHeadline: string;
  linkedinSummary: string;
  linkedinExperience: string;
}

interface ATSScore {
  score: number;
  matches: string[];
  missing: string[];
  suggestions: string[];
}

interface LoginForm {
  email: string;
  password: string;
}

interface PricingTier {
  name: string;
  price: string;
  description: string;
  features: string[];
  icon: React.ReactNode;
  popular?: boolean;
}

function App() {
  const [showCookieConsent, setShowCookieConsent] = useState(true);
  const [step, setStep] = useState<'upload' | 'processing' | 'complete'>('upload');
  const [showLogin, setShowLogin] = useState(false);
  const [showSignup, setShowSignup] = useState(false);
  const [activeAnalysis, setActiveAnalysis] = useState<'keywords' | 'summary' | 'projects' | 'responsibilities' | 'cover'>('keywords');
  const [selectedTier, setSelectedTier] = useState<string>('');
  const [atsScore, setAtsScore] = useState<ATSScore>({
    score: 85,
    matches: ['Python', 'SQL', 'ETL', 'AWS'],
    missing: ['Spark', 'Kafka'],
    suggestions: ['Add specific metrics for ETL pipeline performance', 'Include cloud certification details']
  });

  const pricingTiers: PricingTier[] = [
    {
      name: 'Free',
      price: '$0',
      description: 'Perfect for trying out our services',
      icon: <Bot className="w-6 h-6 text-violet-500" />,
      features: [
        '2 CV generations per month',
        'Basic PDF export',
        'Simple ATS check',
        'Standard templates',
        'Email support'
      ]
    },
    {
      name: 'Pro',
      price: '$14.99',
      description: 'Best for active job seekers',
      icon: <Zap className="w-6 h-6 text-violet-500" />,
      popular: true,
      features: [
        'Unlimited CV generations',
        'All export formats (PDF, DOCX)',
        'Advanced ATS optimization',
        'Keyword density analysis',
        'Premium templates',
        'Priority email support',
        'LinkedIn profile optimization'
      ]
    },
    {
      name: 'Premium',
      price: '$39.99',
      description: 'For professionals seeking the best results',
      icon: <Crown className="w-6 h-6 text-violet-500" />,
      features: [
        'Everything in Pro',
        'Real-time AI feedback',
        'Industry-specific keywords',
        '1-on-1 resume review',
        'Interview preparation tips',
        'Priority 24/7 support',
        'Custom branding options'
      ]
    }
  ];
  const [loginForm, setLoginForm] = useState<LoginForm>({
    email: '',
    password: '',
  });
  const [jobDescription, setJobDescription] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [resumeData, setResumeData] = useState<ResumeData>({
    name: '',
    skills: '',
    experience: '',
    certifications: '',
  });
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysis>({
    keywords: '',
    summary: '',
    projects: '',
    responsibilities: '',
    coverLetter: '',
    linkedinHeadline: '',
    linkedinSummary: '',
    linkedinExperience: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!jobDescription.trim()) {
      setAnalysisError('Please provide a job description to analyze');
      return;
    }

    setStep('processing');
    setAnalysisError(null);
    setIsAnalyzing(true);
    
    fetch('http://localhost:3000/api/analyze-resume', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': 'your-secure-api-key-here' // Use the same key as in .env
      },
      body: JSON.stringify({
        jobDescription
      })
    })
    .then(response => {
      if (!response.ok) {
        return response.json().then(data => {
          throw new Error(data.error || 'Analysis failed. Please try again.');
        });
      }
      return response.json();
    })
    .then(data => {
      if (data.error) {
        throw new Error(data.error);
      }

      // Map the Python response to our UI state
      setAiAnalysis({
        keywords: data.analysis.keywords.join(', '),
        summary: data.analysis.summary || '',
        projects: data.analysis.projects || '',
        responsibilities: data.analysis.responsibilities || '',
        coverLetter: data.analysis.coverLetter || '',
        linkedinHeadline: data.analysis.linkedinHeadline || '',
        linkedinSummary: data.analysis.linkedinSummary || '',
        linkedinExperience: data.analysis.linkedinExperience || ''
      });
      
      // Update ATS score
      setAtsScore({
        score: data.analysis.score || 0,
        matches: data.analysis.matches || [],
        missing: data.analysis.missing || [],
        suggestions: data.analysis.suggestions || []
      });
      setStep('complete');
    })
    .catch(error => {
      setAnalysisError(error.message);
      setStep('upload');
    })
    .finally(() => setIsAnalyzing(false));
  };

  const downloadResume = (format: 'pdf' | 'doc' | 'txt') => {
    // TODO: Implement download functionality
    console.log(`Downloading resume in ${format} format`);
  };

  const handleLogin = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement actual login logic
    console.log('Login:', loginForm);
    setShowLogin(false);
  }, [loginForm]);

  const handleSignup = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement actual signup logic
    console.log('Signup:', loginForm);
    setShowSignup(false);
  }, [loginForm]);

  return (
    <div className="min-h-screen bg-[#0D0D14]">
      {showCookieConsent && (
        <div className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-800 p-4 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <p className="text-gray-300 text-sm flex-1">
                We use essential cookies to make our site work. With your consent, we may also use non-essential cookies to improve user experience, personalize content, and analyze website traffic. For these reasons, we may share your site usage data with our social media and analytics partners. By clicking "Accept," you agree to our website's cookie use as described in our Cookie Policy. You can change your cookie settings at any time by clicking "Preferences."
              </p>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowCookieConsent(false)}
                  className="px-4 py-2 text-sm text-gray-400 hover:text-white transition"
                >
                  Preferences
                </button>
                <button
                  onClick={() => setShowCookieConsent(false)}
                  className="px-4 py-2 text-sm text-gray-400 hover:text-white transition"
                >
                  Decline
                </button>
                <button
                  onClick={() => setShowCookieConsent(false)}
                  className="px-4 py-2 text-sm bg-violet-600 text-white rounded-lg hover:bg-violet-700 transition"
                >
                  Accept
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      <nav className="border-b border-gray-800 bg-[#0D0D14]/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center space-x-2">
              <Bot className="w-8 h-8 text-violet-500" />
              <span className="font-semibold text-xl text-white">ResumeRise</span>
            </div>
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setShowLogin(true)} 
                className="text-gray-400 hover:text-white transition flex items-center gap-2"
              >
                <LogIn className="w-4 h-4" />
                Sign In
              </button>
              <button 
                onClick={() => setShowSignup(true)}
                className="bg-violet-600 text-white px-4 py-2 rounded-lg hover:bg-violet-700 transition flex items-center gap-2"
              >
                <UserPlus className="w-4 h-4" />
                Sign Up
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="relative text-center mb-16">
          <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
            <div className="bg-gray-800 text-orange-500 px-4 py-1 rounded-full text-sm inline-flex items-center space-x-2">
              <span>Trusted by</span>
              <span className="bg-orange-500 text-white px-2 py-0.5 rounded-full">10K+</span>
              <span>Professionals</span>
            </div>
          </div>
          <div className="relative">
            <h1 className="text-5xl font-bold text-white mb-6 leading-tight tracking-tight">
              AI-Powered Job Analysis
              <br />
              & Resume Enhancement
            </h1>
          </div>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-8">
            Share a job description and let our AI analyze it to help you create the perfect application.
            Get tailored keywords, responsibilities, and optimized content to stand out.
          </p>
          <button 
            onClick={() => document.getElementById('job-description')?.focus()}
            className="bg-violet-600 text-white px-8 py-3 rounded-lg text-lg hover:bg-violet-700 transition"
          >
            Analyze a Job Description
          </button>
        </div>

        <div className="max-w-3xl mx-auto">
          {step === 'upload' && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-8">
              <div className="flex items-center justify-center mb-8">
                <div className="flex items-center space-x-8">
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full bg-violet-900/50 flex items-center justify-center mb-2">
                      <Code className="w-6 h-6 text-violet-500" />
                    </div>
                    <span className="text-sm font-medium text-gray-300">Upload</span>
                  </div>
                  <div className="w-24 h-0.5 bg-gray-800" />
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full bg-gray-800 flex items-center justify-center mb-2">
                      <Sparkles className="w-6 h-6 text-gray-400" />
                    </div>
                    <span className="text-sm font-medium text-gray-400">Enhance</span>
                  </div>
                  <div className="w-24 h-0.5 bg-gray-800" />
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full bg-gray-800 flex items-center justify-center mb-2">
                      <FileText className="w-6 h-6 text-gray-400" />
                    </div>
                    <span className="text-sm font-medium text-gray-400">Download</span>
                  </div>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Job Description
                  </label>
                  <div className="relative">
                  <textarea
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                    id="job-description"
                    className="w-full h-32 px-4 py-3 bg-gray-800 border-gray-700 text-white rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-violet-500"
                    placeholder="Paste the job description here..."
                  />
                  {jobDescription && (
                    <button
                      onClick={handleSubmit}
                      className="absolute right-2 bottom-2 bg-violet-600 text-white px-4 py-2 rounded-lg hover:bg-violet-700 transition flex items-center gap-2"
                    >
                      <Sparkles className="w-4 h-4" />
                      Analyze
                    </button>
                  )}
                  </div>
                </div>

                {analysisError && (
                  <div className="p-4 bg-red-900/20 border border-red-800 rounded-lg text-red-400">
                    {analysisError}
                  </div>
                )}
              </form>
            </div>
          )}

          {step === 'processing' && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-8 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-violet-600 border-t-transparent mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-white mb-2">Analyzing Job Description</h2>
              <p className="text-gray-400">
                Our AI is analyzing the job requirements and preparing insights...
              </p>
            </div>
          )}

          {step === 'complete' && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-white">Job Analysis Results</h2>
                <div className="flex items-center gap-4">
                  {isAnalyzing && (
                    <div className="flex items-center gap-2 text-violet-400">
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-violet-500 border-t-transparent" />
                      Analyzing...
                    </div>
                  )}
                  <button
                    onClick={() => setStep('upload')}
                    className="text-gray-400 hover:text-white transition"
                  >
                    Analyze Another Job
                  </button>
                </div>
              </div>
              
              {/* Analysis Options */}
            </div>
          )}

          {step === 'processing' && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-8 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-violet-600 border-t-transparent mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-white mb-2">Analyzing Your Resume</h2>
              <p className="text-gray-400">
                Our AI is reviewing your content and preparing suggestions...
              </p>
            </div>
          )}

          {step === 'complete' && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-8">
              <h2 className="text-xl font-semibold text-white mb-6">AI Analysis & Enhancement</h2>
              
              {/* Analysis Options */}
              <div className="flex flex-wrap gap-4 mb-8">
                <button
                  onClick={() => setActiveAnalysis('keywords')}
                  className={`px-4 py-2 rounded-lg flex items-center gap-2 transition ${
                    activeAnalysis === 'keywords' 
                      ? 'bg-violet-600 text-white' 
                      : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  <Code className="w-4 h-4" />
                  Extract Keywords
                </button>
                <button
                  onClick={() => setActiveAnalysis('summary')}
                  className={`px-4 py-2 rounded-lg flex items-center gap-2 transition ${
                    activeAnalysis === 'summary'
                      ? 'bg-violet-600 text-white'
                      : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  <FileText className="w-4 h-4" />
                  Generate Summary
                </button>
                <button
                  onClick={() => setActiveAnalysis('projects')}
                  className={`px-4 py-2 rounded-lg flex items-center gap-2 transition ${
                    activeAnalysis === 'projects'
                      ? 'bg-violet-600 text-white'
                      : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  <Briefcase className="w-4 h-4" />
                  Sample Projects
                </button>
                <button
                  onClick={() => setActiveAnalysis('responsibilities')}
                  className={`px-4 py-2 rounded-lg flex items-center gap-2 transition ${
                    activeAnalysis === 'responsibilities'
                      ? 'bg-violet-600 text-white'
                      : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  <Bot className="w-4 h-4" />
                  Roles & Responsibilities
                </button>
                <button
                  onClick={() => setActiveAnalysis('cover')}
                  className={`px-4 py-2 rounded-lg flex items-center gap-2 transition ${
                    activeAnalysis === 'cover'
                      ? 'bg-violet-600 text-white'
                      : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  <FileText className="w-4 h-4" />
                  Cover Letter
                </button>
              </div>

              {/* ATS Score Section */}
              <div className="mb-8 p-6 bg-gray-800 rounded-xl border border-gray-700">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium text-white">ATS Compatibility Score</h3>
                  <div className="flex items-center">
                    <div className="w-16 h-16 rounded-full border-4 border-violet-500 flex items-center justify-center">
                      <span className="text-2xl font-bold text-white">{atsScore.score}%</span>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                  <div className="p-4 bg-gray-900/50 rounded-lg">
                    <h4 className="text-violet-400 font-medium mb-2">Matching Keywords</h4>
                    <ul className="space-y-1">
                      {atsScore.matches.map((keyword, index) => (
                        <li key={index} className="text-green-400 flex items-center gap-2">
                          <Check className="w-4 h-4" />
                          {keyword}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="p-4 bg-gray-900/50 rounded-lg">
                    <h4 className="text-violet-400 font-medium mb-2">Missing Keywords</h4>
                    <ul className="space-y-1">
                      {atsScore.missing.map((keyword, index) => (
                        <li key={index} className="text-red-400">• {keyword}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="p-4 bg-gray-900/50 rounded-lg">
                    <h4 className="text-violet-400 font-medium mb-2">Suggestions</h4>
                    <ul className="space-y-1">
                      {atsScore.suggestions.map((suggestion, index) => (
                        <li key={index} className="text-gray-300 text-sm">• {suggestion}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
              
              <div className="space-y-6">
                {activeAnalysis === 'keywords' && (
                  <div className="p-4 bg-violet-900/20 rounded-lg border border-violet-800">
                    <h3 className="font-medium text-violet-400 mb-4">Keywords Analysis</h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-sm font-medium text-violet-300 mb-2">Skills</h4>
                        <p className="text-violet-200 bg-violet-900/30 p-3 rounded-lg">
                          {aiAnalysis.keywords}
                        </p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-violet-300 mb-2">Tools</h4>
                        <p className="text-violet-200 bg-violet-900/30 p-3 rounded-lg">
                          {aiAnalysis.keywords}
                        </p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-violet-300 mb-2">Certifications</h4>
                        <p className="text-violet-200 bg-violet-900/30 p-3 rounded-lg">
                          {aiAnalysis.keywords}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {activeAnalysis === 'summary' && (
                  <div className="p-4 bg-emerald-900/20 rounded-lg border border-emerald-800">
                    <h3 className="font-medium text-emerald-400 mb-4">Professional Summary</h3>
                    <p className="text-emerald-200 bg-emerald-900/30 p-3 rounded-lg whitespace-pre-line">
                      {aiAnalysis.summary}
                    </p>
                  </div>
                )}

                {activeAnalysis === 'projects' && (
                  <div className="p-4 bg-blue-900/20 rounded-lg border border-blue-800">
                    <h3 className="font-medium text-blue-400 mb-4">Sample Projects</h3>
                    <p className="text-blue-200 bg-blue-900/30 p-3 rounded-lg whitespace-pre-line">
                      {aiAnalysis.projects}
                    </p>
                  </div>
                )}

                {activeAnalysis === 'responsibilities' && (
                  <div className="p-4 bg-orange-900/20 rounded-lg border border-orange-800">
                    <h3 className="font-medium text-orange-400 mb-4">Roles & Responsibilities</h3>
                    <p className="text-orange-200 bg-orange-900/30 p-3 rounded-lg whitespace-pre-line">
                      {aiAnalysis.responsibilities}
                    </p>
                  </div>
                )}

                {activeAnalysis === 'cover' && (
                  <div className="p-4 bg-blue-900/20 rounded-lg border border-blue-800">
                    <h3 className="font-medium text-blue-400 mb-4">Cover Letter</h3>
                    <p className="text-blue-200 bg-blue-900/30 p-3 rounded-lg whitespace-pre-line">
                      {aiAnalysis.coverLetter}
                    </p>
                  </div>
                )}

                <div className="p-4 bg-blue-900/20 rounded-lg border border-blue-800">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium text-blue-400">LinkedIn Profile Optimization</h3>
                    <a 
                      href="https://www.linkedin.com/in/" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-sm text-blue-400 hover:text-blue-300 flex items-center gap-2"
                    >
                      <Linkedin className="w-4 h-4" />
                      Update Profile
                    </a>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-blue-300 mb-2">Professional Headline</h4>
                      <p className="text-blue-200 bg-blue-900/30 p-3 rounded-lg">
                        {aiAnalysis.linkedinHeadline}
                      </p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-blue-300 mb-2">Summary</h4>
                      <p className="text-blue-200 bg-blue-900/30 p-3 rounded-lg whitespace-pre-line">
                        {aiAnalysis.linkedinSummary}
                      </p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-blue-300 mb-2">Experience Highlights</h4>
                      <p className="text-blue-200 bg-blue-900/30 p-3 rounded-lg whitespace-pre-line">
                        {aiAnalysis.linkedinExperience}
                      </p>
                    </div>
                    <div className="mt-4 space-y-2 text-sm">
                      <h4 className="font-medium text-blue-300">Profile Tips:</h4>
                      <ul className="list-disc pl-5 space-y-1 text-blue-200">
                        <li>Use a professional headshot photo</li>
                        <li>Add relevant industry keywords for better visibility</li>
                        <li>Include metrics and achievements in experience</li>
                        <li>Connect with industry professionals</li>
                        <li>Engage with relevant content regularly</li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap justify-end gap-4">
                  <button className="px-4 py-2 border border-gray-700 text-gray-300 rounded-lg hover:bg-gray-800">
                    Edit Suggestions
                  </button>
                  <div className="flex gap-2">
                    <button
                      onClick={() => downloadResume('pdf')}
                      className="px-4 py-2 bg-violet-600 text-white rounded-lg hover:bg-violet-700 flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      PDF
                    </button>
                    <button
                      onClick={() => downloadResume('doc')}
                      className="px-4 py-2 bg-violet-600 text-white rounded-lg hover:bg-violet-700 flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      DOC
                    </button>
                    <button
                      onClick={() => downloadResume('txt')}
                      className="px-4 py-2 bg-violet-600 text-white rounded-lg hover:bg-violet-700 flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      TXT
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-12 h-12 rounded-full bg-violet-900/50 flex items-center justify-center mx-auto mb-4">
              <Bot className="w-6 h-6 text-violet-500" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Smart AI Analysis</h3>
            <p className="text-gray-400">
              Our AI analyzes job descriptions to identify key skills and requirements you should highlight.
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 rounded-full bg-violet-900/50 flex items-center justify-center mx-auto mb-4">
              <Briefcase className="w-6 h-6 text-violet-500" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Industry-Specific</h3>
            <p className="text-gray-400">
              Tailored suggestions for different industries and roles, from tech to finance.
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 rounded-full bg-violet-900/50 flex items-center justify-center mx-auto mb-4">
              <FileText className="w-6 h-6 text-violet-500" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">ATS-Optimized</h3>
            <p className="text-gray-400">
              95% success rate in passing ATS systems with our optimized formats.
            </p>
          </div>
        </div>

        {/* Pricing Section */}
        <section className="py-20 bg-gray-900/50 mt-24 rounded-xl border border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-white mb-4">Choose Your Plan</h2>
              <p className="text-xl text-gray-400">
                Get the perfect plan for your career goals
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {pricingTiers.map((tier) => (
                <div
                  key={tier.name}
                  className={`relative bg-gray-800 rounded-xl p-8 border ${
                    tier.popular ? 'border-violet-500' : 'border-gray-700'
                  }`}
                >
                  {tier.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <span className="bg-violet-500 text-white px-4 py-1 rounded-full text-sm">
                        Most Popular
                      </span>
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-2">{tier.name}</h3>
                      <p className="text-gray-400">{tier.description}</p>
                    </div>
                    {tier.icon}
                  </div>
                  
                  <div className="mb-6">
                    <span className="text-4xl font-bold text-white">{tier.price}</span>
                    <span className="text-gray-400">/month</span>
                  </div>
                  
                  <ul className="space-y-4 mb-8">
                    {tier.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-violet-500 mt-0.5" />
                        <span className="text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <button
                    onClick={() => {
                      setSelectedTier(tier.name);
                      setShowSignup(true);
                    }}
                    className={`w-full py-3 rounded-lg font-medium transition ${
                      tier.popular
                        ? 'bg-violet-600 text-white hover:bg-violet-700'
                        : 'bg-gray-700 text-white hover:bg-gray-600'
                    }`}
                  >
                    {tier.name === 'Free' ? 'Get Started' : 'Subscribe Now'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Login Modal */}
        {showLogin && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-gray-900 p-8 rounded-xl border border-gray-800 w-full max-w-md">
              <h2 className="text-2xl font-bold text-white mb-6">Welcome Back</h2>
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={loginForm.email}
                    onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                    className="w-full px-4 py-2 bg-gray-800 border border-gray-700 text-white rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-violet-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Password
                  </label>
                  <input
                    type="password"
                    value={loginForm.password}
                    onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                    className="w-full px-4 py-2 bg-gray-800 border border-gray-700 text-white rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-violet-500"
                    required
                  />
                </div>
                <div className="flex items-center justify-between">
                  <label className="flex items-center">
                    <input type="checkbox" className="form-checkbox text-violet-500" />
                    <span className="ml-2 text-sm text-gray-400">Remember me</span>
                  </label>
                  <a href="#" className="text-sm text-violet-500 hover:text-violet-400">
                    Forgot password?
                  </a>
                </div>
                <button
                  type="submit"
                  className="w-full bg-violet-600 text-white py-2 rounded-lg hover:bg-violet-700 transition"
                >
                  Sign In
                </button>
              </form>
              <button
                onClick={() => setShowLogin(false)}
                className="absolute top-4 right-4 text-gray-400 hover:text-white"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* Signup Modal */}
        {showSignup && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-gray-900 p-8 rounded-xl border border-gray-800 w-full max-w-md">
              <h2 className="text-2xl font-bold text-white mb-6">Create Account</h2>
              <p className="text-gray-400 mb-6">
                Join thousands of professionals who trust ResumeRise for their career growth.
              </p>
              <form onSubmit={handleSignup} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={loginForm.email}
                    onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                    className="w-full px-4 py-2 bg-gray-800 border border-gray-700 text-white rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-violet-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Password
                  </label>
                  <input
                    type="password"
                    value={loginForm.password}
                    onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                    className="w-full px-4 py-2 bg-gray-800 border border-gray-700 text-white rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-violet-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    className="w-full px-4 py-2 bg-gray-800 border border-gray-700 text-white rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-violet-500"
                    required
                  />
                </div>
                <div className="flex items-start gap-2">
                  <input type="checkbox" className="form-checkbox text-violet-500" required />
                  <span className="text-sm text-gray-400">
                    I agree to the{' '}
                    <a href="#" className="text-violet-500 hover:text-violet-400">
                      Terms of Service
                    </a>{' '}
                    and{' '}
                    <a href="#" className="text-violet-500 hover:text-violet-400">
                      Privacy Policy
                    </a>. 
                    By signing up, you acknowledge that you have read and understood our data practices as described in our Privacy Policy.
                  </span>
                </div>
                <button
                  type="submit"
                  className="w-full bg-violet-600 text-white py-2 rounded-lg hover:bg-violet-700 transition"
                >
                  Sign Up
                </button>
                <p className="text-sm text-center text-gray-400">
                  Already have an account?{' '}
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      setShowSignup(false);
                      setShowLogin(true);
                    }}
                    className="text-violet-500 hover:text-violet-400"
                  >
                    Sign in
                  </button>
                </p>
              </form>
              <button
                onClick={() => setShowSignup(false)}
                className="absolute top-4 right-4 text-gray-400 hover:text-white"
              >
                ✕
              </button>
            </div>
          </div>
        )}
      </main>

      <footer className="bg-gray-900 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Bot className="w-8 h-8 text-violet-500" />
                <span className="font-semibold text-xl text-white">ResumeRise</span>
              </div>
              <p className="text-gray-400 mb-4">
                AI-powered resume builder helping professionals land their dream jobs.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-white">
                  <Twitter className="w-5 h-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  <Github className="w-5 h-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  <Linkedin className="w-5 h-5" />
                </a>
              </div>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Product</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white">Features</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Pricing</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Templates</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Examples</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Resources</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white">Resume Guide</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">LinkedIn Tips</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Support</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">API</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Company</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white">About</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Careers</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Privacy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Terms</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>© 2024 ResumeRise. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App