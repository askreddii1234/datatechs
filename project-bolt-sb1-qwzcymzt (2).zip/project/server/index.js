import express from 'express';
import cors from 'cors';
import { PythonShell } from 'python-shell';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { generatePDF } from './utils/documentGenerator.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(cors({
  origin: '*' // For development only - change this for production
}));
app.use(express.json());

// Secure middleware to check API key
const authenticateApiKey = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== process.env.API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
};

app.post('/api/analyze-resume', authenticateApiKey, async (req, res) => {
  try {
    const { resumeText, jobDescription } = req.body;

    // Only require jobDescription for now
    if (!jobDescription) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const options = {
      mode: 'text',
      pythonPath: 'python3',
      pythonOptions: ['-u'], // unbuffered output
      scriptPath: path.join(__dirname, 'python'),
      args: [ // Pass only job description for now
        '--resume', resumeText,
        '--job', jobDescription
      ]
    };

    PythonShell.run('analyze_resume.py', options).then(results => {
      const analysis = JSON.parse(results[0]);
      
      // Send analysis results
      res.json({
        analysis
      });
    }).catch(err => {
      console.error('Python script error:', err);
      res.status(500).json({ error: 'Analysis failed' });
    });
  } catch (error) {
    console.error('Server error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});