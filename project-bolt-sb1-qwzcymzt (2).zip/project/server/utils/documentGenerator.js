import { jsPDF } from 'jspdf';

/**
 * Generates a PDF document from resume analysis
 * @param {Object} analysis - The analysis results from Python
 * @param {string} originalText - The original resume text
 * @returns {Buffer} PDF document as a buffer
 */
export function generatePDF(analysis, originalText) {
  const doc = new jsPDF();
  
  // Add header
  doc.setFontSize(20);
  doc.text('Resume Analysis Report', 20, 20);
  
  // Add score
  doc.setFontSize(16);
  doc.text(`ATS Score: ${analysis.score}%`, 20, 40);
  
  // Add matching keywords
  doc.setFontSize(14);
  doc.text('Matching Keywords:', 20, 60);
  analysis.matches.forEach((keyword, index) => {
    doc.setFontSize(12);
    doc.text(`• ${keyword}`, 30, 70 + (index * 10));
  });
  
  // Add suggestions
  let y = 70 + (analysis.matches.length * 10) + 20;
  doc.setFontSize(14);
  doc.text('Suggestions:', 20, y);
  analysis.suggestions.forEach((suggestion, index) => {
    doc.setFontSize(12);
    const lines = doc.splitTextToSize(suggestion, 170);
    lines.forEach((line, lineIndex) => {
      doc.text(`• ${line}`, 30, y + 10 + (index * 20) + (lineIndex * 10));
    });
  });
  
  // Return as buffer
  return Buffer.from(doc.output('arraybuffer'));
}