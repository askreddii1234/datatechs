#!/usr/bin/env python3
"""
Resume Analysis Script
Analyzes job descriptions using NLP techniques to extract key information
"""

import sys
import json
import argparse
import re
from collections import Counter
from typing import Dict, List, Tuple, Any

# Technical skills and common job-related terms
TECHNICAL_SKILLS = {
    'languages': {'python', 'java', 'javascript', 'typescript', 'c++', 'ruby', 'php', 'scala', 'kotlin', 'swift'},
    'frameworks': {'react', 'angular', 'vue', 'django', 'flask', 'spring', 'express', 'node'},
    'databases': {'sql', 'postgresql', 'mysql', 'mongodb', 'redis', 'elasticsearch'},
    'cloud': {'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'terraform'},
    'tools': {'git', 'jenkins', 'jira', 'confluence', 'bitbucket', 'github'}
}

# Enhanced stop words for job descriptions
STOP_WORDS = {
    'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'with',
    'we', 'are', 'is', 'our', 'you', 'your', 'will', 'be', 'as', 'that', 'have',
    'this', 'by', 'from', 'they', 'we', 'say', 'her', 'his', 'but', 'what',
    'some', 'not', 'do', 'there', 'if', 'must', 'other', 'into', 'more', 'has',
    'about', 'should', 'then', 'out', 'like', 'only', 'after', 'may', 'such'
}

def extract_keywords(text: str) -> List[Tuple[str, int]]:
    """
    Extract important keywords from text with improved technical term recognition
    
    Args:
        text: Input text to analyze
        
    Returns:
        List of tuples containing (keyword, frequency)
    """
    if not text or not isinstance(text, str):
        return []
        
    # Normalize text
    text = text.lower()
    
    # Extract potential technical terms before removing special characters
    technical_terms = []
    for category in TECHNICAL_SKILLS.values():
        for term in category:
            if term in text:
                technical_terms.append(term)
    
    # Remove special characters but preserve hyphenated terms
    text = re.sub(r'[^\w\s-]', ' ', text)
    
    # Split into words and clean up
    words = [word.strip() for word in text.split()]
    
    # Remove stop words and short terms
    keywords = [
        word for word in words 
        if word not in STOP_WORDS 
        and len(word) > 2
    ]
    
    # Add back technical terms to ensure they're not lost
    keywords.extend(technical_terms)
    
    # Count frequencies
    keyword_counts = Counter(keywords)
    
    # Return top keywords with their counts
    return keyword_counts.most_common(20)

def detect_sections(text: str) -> Dict[str, List[str]]:
    """
    Detect and extract sections from job description
    
    Args:
        text: Job description text
        
    Returns:
        Dictionary of section names and their content
    """
    sections = {
        'requirements': [],
        'responsibilities': [],
        'qualifications': [],
        'benefits': []
    }
    
    # Section markers
    section_markers = {
        'requirements': ['requirements', 'required', 'what you need', 'what we need'],
        'responsibilities': ['responsibilities', 'duties', 'what you\'ll do', 'role', 'day to day'],
        'qualifications': ['qualifications', 'skills', 'experience', 'background'],
        'benefits': ['benefits', 'perks', 'what we offer', 'compensation']
    }
    
    lines = text.lower().split('\n')
    current_section = None
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Check if line starts a new section
        for section, markers in section_markers.items():
            if any(marker in line for marker in markers):
                current_section = section
                break
                
        # Add content to current section
        if current_section and line and not any(
            marker in line for markers in section_markers.values() for marker in markers
        ):
            # Clean up bullet points and common prefixes
            cleaned_line = re.sub(r'^[-•*]\s*', '', line)
            if cleaned_line:
                sections[current_section].append(cleaned_line)
    
    return sections

def calculate_score(keywords: List[Tuple[str, int]], sections: Dict[str, List[str]]) -> int:
    """
    Calculate job description completeness score
    
    Args:
        keywords: List of extracted keywords
        sections: Dictionary of parsed sections
        
    Returns:
        Score from 0-100
    """
    score = 0
    
    # Score based on number of keywords (max 40 points)
    keyword_score = min(len(keywords) * 2, 40)
    score += keyword_score
    
    # Score based on section completeness (max 60 points)
    section_weights = {
        'requirements': 20,
        'responsibilities': 20,
        'qualifications': 15,
        'benefits': 5
    }
    
    for section, weight in section_weights.items():
        if sections[section]:
            # More items in a section = higher score, up to the max weight
            items_score = min(len(sections[section]) * 2, weight)
            score += items_score
            
    return score

def analyze_job_description(job_description: str) -> Dict[str, Any]:
    """
    Analyze job description and extract relevant information
    
    Args:
        job_description: Text of the job description
        
    Returns:
        Dictionary containing analysis results
    """
    if not job_description or not isinstance(job_description, str):
        raise ValueError("Invalid job description")
        
    if len(job_description.strip()) < 10:
        raise ValueError("Job description too short")
    
    # Extract keywords
    keywords = extract_keywords(job_description)
    keyword_list = [word for word, _ in keywords]
    
    # Detect sections
    sections = detect_sections(job_description)
    
    # Calculate score
    score = calculate_score(keywords, sections)
    
    # Generate suggestions
    suggestions = []
    
    if score < 60:
        suggestions.append("Job description needs more detail in requirements and responsibilities")
    if len(keyword_list) < 10:
        suggestions.append("Add more specific technical skills and requirements")
    if not sections['benefits']:
        suggestions.append("Consider adding benefits/perks section")
    
    # Technical skills analysis
    tech_skills = []
    for category, skills in TECHNICAL_SKILLS.items():
        found_skills = [skill for skill in skills if skill in job_description.lower()]
        if found_skills:
            tech_skills.extend(found_skills)
    
    return {
        'score': score,
        'keywords': keyword_list,
        'technical_skills': tech_skills,
        'sections': sections,
        'suggestions': suggestions
    }

def main():
    parser = argparse.ArgumentParser(description='Analyze job description')
    parser.add_argument('--job', required=True, help='Job description text')
    
    args = parser.parse_args()
    
    try:
        analysis = analyze_job_description(args.job)
        print(json.dumps(analysis, indent=2))
    except Exception as e:
        print(json.dumps({
            'error': str(e),
            'status': 'error'
        }))

if __name__ == "__main__":
    main()