#!/usr/bin/env python3
"""
Test script for job description analysis
"""

import json
from analyze_resume import extract_keywords, analyze_job_description, detect_sections

def test_keyword_extraction():
    print("\n=== Testing Keyword Extraction ===")
    test_cases = [
        # Technical job description
        """
        Senior Software Engineer
        Required Skills:
        - Python, JavaScript, TypeScript
        - React, Node.js, Express
        - PostgreSQL, Redis
        - AWS, Docker, Kubernetes
        """,
        
        # Non-technical job description
        """
        Marketing Manager
        Looking for an experienced marketing professional with:
        - Digital marketing expertise
        - Social media management
        - Content strategy
        - Analytics and reporting
        """,
        
        # Mixed case and special characters
        """
        DevOps/SRE Engineer
        Must know: AWS, K8s, Docker, CI/CD
        Experience with Python/Go
        Terraform & Infrastructure-as-Code
        """
    ]
    
    for text in test_cases:
        print("\nInput:", text[:50] + "...")
        keywords = extract_keywords(text)
        print("Keywords:", keywords)

def test_section_detection():
    print("\n=== Testing Section Detection ===")
    test_descriptions = [
        # Standard format
        """
        Requirements:
        - 5+ years of software development
        - Strong Python skills
        - AWS experience
        
        Responsibilities:
        - Develop scalable applications
        - Code review and mentoring
        - Technical architecture
        
        Qualifications:
        - Bachelor's in CS or related
        - Previous tech lead experience
        
        Benefits:
        - Competitive salary
        - Remote work options
        - Health insurance
        """,
        
        # Alternative format
        """
        WHAT YOU'LL DO:
        * Lead development projects
        * Mentor junior developers
        
        WHAT YOU NEED:
        * Strong coding skills
        * Team leadership experience
        
        WHAT WE OFFER:
        * Great work environment
        * Learning opportunities
        """
    ]
    
    for desc in test_descriptions:
        print("\nInput:", desc[:50] + "...")
        sections = detect_sections(desc)
        print("Sections:", json.dumps(sections, indent=2))

def test_error_handling():
    print("\n=== Testing Error Handling ===")
    test_cases = [
        ("", "Empty string"),
        (None, "None value"),
        ("   ", "Whitespace only"),
        ("a" * 10000, "Very long input"),
        (123, "Non-string input"),
        ("Too short", "Short input")
    ]
    
    for test_input, label in test_cases:
        print(f"\nTesting: {label}")
        try:
            result = analyze_job_description(test_input)
            print("Result:", result)
        except Exception as e:
            print("Error (expected):", str(e))

def test_full_analysis():
    print("\n=== Testing Full Analysis ===")
    test_description = """
    Senior Full Stack Developer
    
    Requirements:
    - 5+ years experience with modern JavaScript/TypeScript
    - Strong expertise in React and Node.js
    - Experience with PostgreSQL and Redis
    - AWS cloud infrastructure knowledge
    - CI/CD and DevOps practices
    
    Responsibilities:
    - Design and develop scalable web applications
    - Lead technical architecture decisions
    - Mentor junior developers
    - Collaborate with product and design teams
    - Implement best practices and coding standards
    
    Qualifications:
    - Bachelor's degree in Computer Science or related field
    - Previous tech lead experience
    - Strong problem-solving skills
    - Excellent communication abilities
    
    Benefits:
    - Competitive salary and equity
    - Remote work options
    - Health and dental insurance
    - Professional development budget
    - Flexible vacation policy
    """
    
    try:
        result = analyze_job_description(test_description)
        print("\nAnalysis Result:")
        print(json.dumps(result, indent=2))
    except Exception as e:
        print("Error:", str(e))

def main():
    print("Running Job Analysis Tests")
    print("=" * 50)
    
    test_keyword_extraction()
    test_section_detection()
    test_error_handling()
    test_full_analysis()
    
    print("\nTests completed!")

if __name__ == "__main__":
    main()