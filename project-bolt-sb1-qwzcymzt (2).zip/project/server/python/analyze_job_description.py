import os
import openai
import pdfkit
import docx  # from python-docx

from flask import Flask, request, render_template, session, redirect, url_for, send_file
from io import BytesIO

app = Flask(__name__)
app.secret_key = "SUPER_SECRET_KEY"  # For session usage in demo

# Set OpenAI API Key (environment variable recommended)
openai.api_key = os.getenv("OPENAI_API_KEY")

if not openai.api_key:
    raise ValueError("OpenAI API key not found in environment variables")

# If wkhtmltopdf is not in PATH, set explicit path:
# pdfkit_config = pdfkit.configuration(wkhtmltopdf="/usr/bin/wkhtmltopdf")
pdfkit_config = None

@app.route("/", methods=["GET", "POST"])
def index():
    """
    Main route:
      1) Job description input
      2) Detect job role automatically
      3) Generate keywords, summary, projects, responsibilities
      4) Generate cover letter
      5) Capture user data (CV info)
      6) Clear data or download multiple formats
    """
    # Load or initialize session variables
    extracted_keywords = session.get("extracted_keywords", "")
    generated_summary = session.get("generated_summary", "")
    generated_projects = session.get("generated_projects", "")
    generated_responsibilities = session.get("generated_responsibilities", "")
    generated_cover_letter = session.get("generated_cover_letter", "")

    # CV data (including the detected role)
    resume_data = session.get("resume_data", {
        "name": "",
        "skills": "",
        "experience": "",
        "certifications": "",
    })
    detected_role = session.get("detected_role", "")  # e.g., "Data Engineer" or "Software Developer"

    if request.method == "POST":
        action = request.form.get("action", "")
        job_desc = request.form.get("job_description", "").strip()

        # 1. Detect role automatically once the user provides a job description
        if job_desc:
            role = detect_role(job_desc)
            session["detected_role"] = role
            detected_role = role  # store in local variable for immediate use

        if action == "extract_keywords":
            extracted_keywords = extract_keywords(job_desc, detected_role)
            session["extracted_keywords"] = extracted_keywords

        elif action == "generate_summary":
            generated_summary = generate_summary(job_desc, detected_role)
            session["generated_summary"] = generated_summary

        elif action == "generate_projects":
            generated_projects = generate_projects(job_desc, detected_role)
            session["generated_projects"] = generated_projects

        elif action == "generate_responsibilities":
            generated_responsibilities = generate_responsibilities(job_desc, detected_role)
            session["generated_responsibilities"] = generated_responsibilities

        elif action == "generate_cover_letter":
            # Use the job description + personal data + detected role
            generated_cover_letter = generate_cover_letter(job_desc, resume_data, detected_role)
            session["generated_cover_letter"] = generated_cover_letter

        elif action == "update_data":
            # Update personal data in session
            resume_data = {
                "name": request.form.get("name", ""),
                "skills": request.form.get("skills", ""),
                "experience": request.form.get("experience", ""),
                "certifications": request.form.get("certifications", "")
            }
            session["resume_data"] = resume_data

        elif action == "download_pdf":
            return redirect(url_for("download_pdf"))

        elif action == "download_doc":
            return redirect(url_for("download_doc"))

        elif action == "download_txt":
            return redirect(url_for("download_txt"))

        elif action == "download_cover_letter_pdf":
            return redirect(url_for("download_cover_letter_pdf"))

        elif action == "download_cover_letter_doc":
            return redirect(url_for("download_cover_letter_doc"))

        elif action == "download_cover_letter_txt":
            return redirect(url_for("download_cover_letter_txt"))

        elif action == "clear_data":
            session.clear()

        return redirect(url_for("index"))

    return render_template(
        "index.html",
        extracted_keywords=extracted_keywords,
        generated_summary=generated_summary,
        generated_projects=generated_projects,
        generated_responsibilities=generated_responsibilities,
        generated_cover_letter=generated_cover_letter,
        resume_data=resume_data,
        detected_role=detected_role
    )


# ------------------------------------------------
#  Helpers to Detect Role & Generate AI Content
# ------------------------------------------------

def detect_role(job_description: str) -> str:
    """
    Uses OpenAI to analyze the job description and identify the most likely role/title.
    E.g., "Data Engineer", "DevOps Engineer", "Software Developer", etc.
    """
    if not job_description:
        return "IT Professional"  # fallback if no job desc

    prompt = (
        "Analyze the following job description. Identify the primary job role or title. "
        "For example, respond with 'Data Engineer', 'Software Developer', 'DevOps Engineer', "
        "'IT Support Specialist', etc.\n\n"
        f"Job Description:\n{job_description}\n\n"
        "Your response should be concise, just the role/title without extra commentary."
    )
    response = chat_with_openai(prompt)
    # It's possible the model might return a sentence; let's keep just the role.
    # We'll do a simple heuristic to pick the first line or so.
    role = response.split("\n")[0].strip()
    return role if role else "IT Professional"


def extract_keywords(job_description: str, role: str) -> str:
    """
    Extract relevant skills/tools/certs from the job description for a detected role.
    """
    if not job_description:
        return "No job description provided."

    # Use the 'role' in the prompt to give more context
    prompt = (
        f"The role is '{role}'. Analyze the following job description. "
        "Extract relevant skills, tools, certifications, and other keywords. "
        "Output format:\n"
        "- Skills: [list skills]\n"
        "- Tools: [list tools]\n"
        "- Certifications: [list certifications]\n"
        "- Keywords: [list other relevant terms]\n\n"
        f"Job Description:\n{job_description}\n"
    )
    return chat_with_openai(prompt)


def generate_summary(job_description: str, role: str) -> str:
    """
    Generate a short, ATS-friendly professional summary for the detected role.
    """
    if not job_description:
        return "No job description provided."

    prompt = (
        f"Write a concise, professional summary suitable for a CV/resume targeting the role '{role}'. "
        "Focus on relevant technical skills, collaboration, and role-specific highlights.\n\n"
        f"Job Description:\n{job_description}\n"
    )
    return chat_with_openai(prompt)


def generate_projects(job_description: str, role: str) -> str:
    """
    Generate sample project descriptions aligned with the job description for the detected role.
    """
    if not job_description:
        return "No job description provided."
    
    prompt = (
        f"Based on the following job description for the role '{role}', propose "
        "2-3 sample project descriptions the candidate might have worked on. "
        "Each should highlight relevant skills, tools, and achievements.\n\n"
        f"Job Description:\n{job_description}\n"
    )
    return chat_with_openai(prompt)


def generate_responsibilities(job_description: str, role: str) -> str:
    """
    Generate bullet-pointed roles & responsibilities for the detected role.
    """
    if not job_description:
        return "No job description provided."
    
    prompt = (
        f"Based on the following job description for the role '{role}', generate "
        "5-6 bullet points for roles & responsibilities. Include relevant "
        "metrics or achievements where possible.\n\n"
        f"Job Description:\n{job_description}\n"
    )
    return chat_with_openai(prompt)


def generate_cover_letter(job_description: str, resume_data: dict, role: str) -> str:
    """
    Generate a cover letter that appears human-written for the detected role.
    """
    if not job_description:
        return "No job description provided."

    name = resume_data.get("name", "No Name Provided")
    skills = resume_data.get("skills", "")
    experience = resume_data.get("experience", "")
    certifications = resume_data.get("certifications", "")

    prompt = (
        f"You are applying for a '{role}' position. Your name is {name}. "
        f"You have skills in {skills}, experience including {experience}, "
        f"and certifications: {certifications}.\n\n"
        "Write a short, personalized cover letter that truly sounds human-written. "
        "The letter should:\n"
        "- Emphasize the key skills relevant to this role.\n"
        "- Use a formal but friendly tone.\n"
        "- Avoid typical 'AI-sounding' language.\n"
        "- Be one page or less.\n\n"
        f"Job Description:\n{job_description}\n"
    )
    return chat_with_openai(prompt)


# ------------------------
# OpenAI Chat Helper
# ------------------------

def chat_with_openai(prompt: str) -> str:
    """Helper function that calls OpenAI's ChatCompletion API (gpt-3.5-turbo)."""
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=700,
            temperature=0.7
        )
        return response.choices[0].message["content"].strip()
    except Exception as e:
        return f"OpenAI Error: {str(e)}"


# ------------------------------------------------
# Routes for Downloading the CV in Multiple Formats
# ------------------------------------------------

@app.route("/download_pdf", methods=["GET"])
def download_pdf():
    """Generate and download a PDF CV for the detected role."""
    rdata = session.get("resume_data", {})
    detected_role = session.get("detected_role", "IT Professional")

    name = rdata.get("name", "No Name")
    skills = rdata.get("skills", "")
    experience = rdata.get("experience", "")
    certifications = rdata.get("certifications", "")

    projects = session.get("generated_projects", "")
    responsibilities = session.get("generated_responsibilities", "")

    # Convert multi-line text to bullet points
    exp_list = [x.strip() for x in experience.split("\n") if x.strip()]
    cert_list = [x.strip() for x in certifications.split("\n") if x.strip()]

    html_content = f"""
    <html>
    <head>
      <meta charset="UTF-8"/>
      <style>
        body {{
          font-family: Arial, sans-serif;
          margin: 20px;
        }}
        h1, h2 {{
          margin-bottom: 0.5rem;
        }}
        ul {{
          margin: 0;
          padding-left: 20px;
        }}
      </style>
    </head>
    <body>
      <h1>{name} – {detected_role}</h1>
      <h2>Key Skills</h2>
      <p>{skills if skills else "N/A"}</p>

      <h2>Projects</h2>
      <pre style="font-family: inherit;">{projects if projects else "N/A"}</pre>

      <h2>Roles & Responsibilities</h2>
      <pre style="font-family: inherit;">{responsibilities if responsibilities else "N/A"}</pre>

      <h2>Experience</h2>
      <ul>
        {''.join(f"<li>{exp}</li>" for exp in exp_list) if exp_list else "<li>N/A</li>"}
      </ul>

      <h2>Certifications</h2>
      <ul>
        {''.join(f"<li>{cert}</li>" for cert in cert_list) if cert_list else "<li>N/A</li>"}
      </ul>
    </body>
    </html>
    """
    try:
        pdf_data = pdfkit.from_string(html_content, False, configuration=pdfkit_config)
    except Exception as e:
        return f"Error generating PDF: {str(e)}", 500

    return send_file(
        BytesIO(pdf_data),
        as_attachment=True,
        download_name=f"{detected_role}_CV.pdf".replace(" ", "_"),
        mimetype="application/pdf"
    )

@app.route("/download_doc", methods=["GET"])
def download_doc():
    """Generate and download a DOCX version of the CV for the detected role."""
    rdata = session.get("resume_data", {})
    detected_role = session.get("detected_role", "IT Professional")

    name = rdata.get("name", "No Name")
    skills = rdata.get("skills", "")
    experience = rdata.get("experience", "")
    certifications = rdata.get("certifications", "")

    projects = session.get("generated_projects", "")
    responsibilities = session.get("generated_responsibilities", "")

    exp_list = [x.strip() for x in experience.split("\n") if x.strip()]
    cert_list = [x.strip() for x in certifications.split("\n") if x.strip()]

    doc_file = docx.Document()

    doc_file.add_heading(f"{name} – {detected_role}", 0)

    doc_file.add_heading("Key Skills", level=1)
    doc_file.add_paragraph(skills if skills else "N/A")

    doc_file.add_heading("Projects", level=1)
    doc_file.add_paragraph(projects if projects else "N/A")

    doc_file.add_heading("Roles & Responsibilities", level=1)
    doc_file.add_paragraph(responsibilities if responsibilities else "N/A")

    doc_file.add_heading("Experience", level=1)
    if exp_list:
        for exp in exp_list:
            doc_file.add_paragraph(exp, style='List Bullet')
    else:
        doc_file.add_paragraph("N/A")

    doc_file.add_heading("Certifications", level=1)
    if cert_list:
        for cert in cert_list:
            doc_file.add_paragraph(cert, style='List Bullet')
    else:
        doc_file.add_paragraph("N/A")

    buf = BytesIO()
    doc_file.save(buf)
    buf.seek(0)

    return send_file(
        buf,
        as_attachment=True,
        download_name=f"{detected_role}_CV.docx".replace(" ", "_"),
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )

@app.route("/download_txt", methods=["GET"])
def download_txt():
    """Generate a plain text version of the CV for the detected role."""
    rdata = session.get("resume_data", {})
    detected_role = session.get("detected_role", "IT_Professional")

    name = rdata.get("name", "No Name")
    skills = rdata.get("skills", "")
    experience = rdata.get("experience", "")
    certifications = rdata.get("certifications", "")

    projects = session.get("generated_projects", "")
    responsibilities = session.get("generated_responsibilities", "")

    exp_list = [x.strip() for x in experience.split("\n") if x.strip()]
    cert_list = [x.strip() for x in certifications.split("\n") if x.strip()]

    text_cv = []
    text_cv.append(f"{name} – {detected_role}\n\n")
    text_cv.append("Key Skills:\n")
    text_cv.append(f"{skills if skills else 'N/A'}\n\n")
    text_cv.append("Projects:\n")
    text_cv.append(f"{projects if projects else 'N/A'}\n\n")
    text_cv.append("Roles & Responsibilities:\n")
    text_cv.append(f"{responsibilities if responsibilities else 'N/A'}\n\n")
    text_cv.append("Experience:\n")

    if exp_list:
        for exp in exp_list:
            text_cv.append(f"- {exp}\n")
    else:
        text_cv.append("- N/A\n")
    text_cv.append("\n")

    text_cv.append("Certifications:\n")
    if cert_list:
        for cert in cert_list:
            text_cv.append(f"- {cert}\n")
    else:
        text_cv.append("- N/A\n")

    final_text = "".join(text_cv)

    return send_file(
        BytesIO(final_text.encode("utf-8")),
        as_attachment=True,
        download_name=f"{detected_role}_CV.txt".replace(" ", "_"),
        mimetype="text/plain"
    )

# --------------------------------------------------
# Routes for Downloading the Cover Letter (All Formats)
# --------------------------------------------------

# Optionally add a PDF route if you want a PDF version of the cover letter.
# Below, we have DOCX and TXT as examples.

@app.route("/download_cover_letter_doc", methods=["GET"])
def download_cover_letter_doc():
    """Generate and download a DOCX cover letter for the detected role."""
    cover_letter = session.get("generated_cover_letter", "")
    detected_role = session.get("detected_role", "IT_Professional")

    if not cover_letter:
        cover_letter = "No cover letter generated."

    doc_file = docx.Document()
    for paragraph in cover_letter.split("\n"):
        doc_file.add_paragraph(paragraph)

    buf = BytesIO()
    doc_file.save(buf)
    buf.seek(0)

    return send_file(
        buf,
        as_attachment=True,
        download_name=f"{detected_role}_CoverLetter.docx".replace(" ", "_"),
        mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )

@app.route("/download_cover_letter_txt", methods=["GET"])
def download_cover_letter_txt():
    """Generate and download a plain text cover letter for the detected role."""
    cover_letter = session.get("generated_cover_letter", "")
    detected_role = session.get("detected_role", "IT_Professional")

    if not cover_letter:
        cover_letter = "No cover letter generated."

    return send_file(
        BytesIO(cover_letter.encode("utf-8")),
        as_attachment=True,
        download_name=f"{detected_role}_CoverLetter.txt".replace(" ", "_"),
        mimetype="text/plain"
    )


if __name__ == "__main__":
    app.run(debug=True)